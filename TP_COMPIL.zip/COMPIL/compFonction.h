typedef struct
{
char NomEntite[20];
char CodeEntite[20];
char TypeEntite[20];
int TailleEntite;
} TypeTS;

//initiation d'un tableau qui va contenir les elements de la table de symbole
TypeTS ts[100]; 

// un compteur global pour la table de symbole
int CpTabSym=0;


//une fonctione recherche: pour chercher est ce que l'entit� existe ou non d�j� dans la table de symbole.
// i: l'entite existe dej� dans la table de symbole, et sa position est i, -1: l'entit� n'existe pas dans la table de symbole.

int recherche(char entite[])
{
int i=0;
while(i<CpTabSym)
{
if (strcmp(entite,ts[i].NomEntite)==0) return i;
i++;
}

return -1;
}

//une fontion qui va ins�rer les entit�s de programme dans la table de symbole
void inserer(char entite[], char code[] )
{

if ( recherche(entite)==-1)
{
strcpy(ts[CpTabSym].NomEntite,entite); 
strcpy(ts[CpTabSym].CodeEntite,code);
ts[CpTabSym].TailleEntite=1;




//printf("lentite est %s, sont type est %s , sa taille est  %d . (%d)\n",ts[CpTabSym].NomEntite,ts[CpTabSym].TypeEntite,ts[CpTabSym].TailleEntite,CpTabSym);
CpTabSym++;
}
}

//une fonction pour afficher la table de symbole
void afficher ()
{
printf("\n/***************Table des symboles ******************/\n");
printf("_____________________________________________________________\n");
printf("\t| NomEntite |  CodeEntite  |  TypeEntite | Taille \n");
printf("_____________________________________________________________\n");
int i=0;
while(i<CpTabSym)
{

printf("\t|%10s |%12s  |%12s |%8d   |\n",ts[i].NomEntite,ts[i].CodeEntite,ts[i].TypeEntite,ts[i].TailleEntite);

i++;
}
}


// fonction qui change le type d'une etit� une fois il va �tre reconu dans la syntaxe 

void insererType(char entite[], char type[])
{

int posEntite=recherche(entite);
if (posEntite!=-1)
{ 

strcpy(ts[posEntite].TypeEntite,type);

//printf("lentite est %s, sont type est %s %d\n",ts[CpTabSym].NomEntite,ts[CpTabSym].TypeEntite,CpTabSym);

}
}

void insererTaille(char entite[], int taille)
{

    int posEntite=recherche(entite);

    if (posEntite!=-1)
    {
        ts[posEntite].TailleEntite=taille;
    }
}





//////////////////////////////////////////////////////
////Les routines s�mantiques

/*

int doubleDeclaration (char entite[])
{
int posEntite=recherche(entite);

//printf ("\nposi %d\n",posEntite);
if (strcmp(ts[posEntite].TypeEntite,"")==0) return 1;  // j'ai pas trouv� le type associ� � l'entit� dans le table de symbole et donc elle est pas encore d�clar�e
else return 0; // le type de l'entit� existe dej� dans la TS et donc c'est une double d�claration

}
*/

// ● Double déclaration

void doubleDeclaration (char entite[], char type[], int numLigne)
{
   
    int posEntite=recherche(entite);

    if (strcmp(ts[posEntite].TypeEntite,"")==0) {
        insererType(entite,type);
    } else {
        /*errur semantique + num ligne de lerreur */
        printf("Erreur semantique [ligne %d]: l'entite %s est deja declaree. \n",numLigne,entite);

    }

}









void nonDeclaration (char entite[], int numLigne)
{
    

    int posEntite=recherche(entite);

    if (strcmp(ts[posEntite].TypeEntite,"")==0) {
        printf("Erreur semantique [ligne %d]: l'entite %s n'est pas declaree. \n",numLigne,entite);
    } 

}


//● Dépassement de la taille d’un tableau,

void depassementTailleTableau (char entite[], int taille, int numLigne)
{

    int posEntite=recherche(entite);

    if (strcmp(ts[posEntite].TypeEntite,"")==1) {

        if (taille > ts[posEntite].TailleEntite) {
            printf("Erreur semantique [ligne %d]: depassement de la taille du tableau %s. \n",numLigne,entite);
        }

    }
    

}

void verifBibIO (int io, int numLigne)
{
    if (io == 0) {
        printf("Erreur semantique [ligne %d]: Absence d'une bibliotheque necessaire (isil.io). \n",numLigne);
    }
}

void verifBibLang (int lang, int numLigne)
{
    if (lang == 0) {
        printf("Erreur semantique [ligne %d]: Absence d'une bibliotheque necessaire (isil.lang). \n",numLigne);
    }
}

void checkSigneIn (char entite[], char signe[] , int numLigne)
{
    int posEntite=recherche(entite);
    int sf ;

    // in ("%d", ali ) ;
    // check if the variable type matches the formatage

    if (strcmp(ts[posEntite].TypeEntite,"")==1) {

       
        

        if (strcmp(signe,"%d")==0){ sf = 1; }
        else if (strcmp(signe,"%f")==0){ sf = 2; }
        else if (strcmp(signe,"%s")==0){ sf = 3; }
        else { sf = 0; }


        switch (sf)
        {
            case 1:
                if (strcmp(ts[posEntite].TypeEntite,"int")!=0) {
                    printf("Erreur semantique [ligne %d]: le type de la variable %s ne correspond pas au formatage %s. \n",numLigne,entite,signe);
                }
                break;

            case 2:
                if (strcmp(ts[posEntite].TypeEntite,"real")!=0) {
                    printf("Erreur semantique [ligne %d]: le type de la variable %s ne correspond pas au formatage %s. \n",numLigne,entite,signe);
                }
                break;

            case 3:
                if (strcmp(ts[posEntite].TypeEntite,"string")!=0) {
                    printf("Erreur semantique [ligne %d]: le type de la variable %s ne correspond pas au formatage %s. \n",numLigne,entite,signe);
                }
                break;
            
            default:
                printf("Erreur semantique [ligne %d]: le signe de formatage %s n'est pas valide. \n",numLigne,signe);
                break;
        }

    }










}

// compatible types

void compatibleTypes (char entite1[], int type, int numLigne)
{
    // type = 1 : int
    // type = 2 : string
    // type = 3 : real

    int posEntite=recherche(entite1);

    if (strcmp(ts[posEntite].TypeEntite,"")==1) {

        if (type == 1) {
            if (strcmp(ts[posEntite].TypeEntite,"int")!=0) {
                printf("Erreur semantique [ligne %d]: le type de la variable %s n'est pas compatible avec le type int. \n",numLigne,entite1);
            }
        } else if (type == 2) {
            if (strcmp(ts[posEntite].TypeEntite,"string")!=0) {
                printf("Erreur semantique [ligne %d]: le type de la variable %s n'est pas compatible avec le type string. \n",numLigne,entite1);
            }
        } else if (type == 3) {
            if (strcmp(ts[posEntite].TypeEntite,"real")!=0) {
                printf("Erreur semantique [ligne %d]: le type de la variable %s n'est pas compatible avec le type real. \n",numLigne,entite1);
            }
        } else {
            printf("Erreur semantique [ligne %d]: le type %d n'est pas valide. \n",numLigne,type);
        }

    }
    

}






















